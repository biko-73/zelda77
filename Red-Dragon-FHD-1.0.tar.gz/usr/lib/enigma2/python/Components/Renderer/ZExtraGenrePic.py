# -*- coding: utf-8 -*-
from __future__ import absolute_import
from Components.Renderer.Renderer import Renderer
from enigma import ePixmap
from Components.config import config
import json
import re
import os

PIC_PATH = "/usr/share/enigma2/genre_pic/"

class ZExtraGenrePic(Renderer):

	def __init__(self):
		Renderer.__init__(self)

	GUI_WIDGET = ePixmap

	def postWidgetCreate(self, instance):
		self.changed((self.CHANGED_DEFAULT,))

	def changed(self, what):
		if self.instance:
			if what[0] == self.CHANGED_CLEAR:
				self.instance.setPixmap(None)
			else:
				found = False
				event = self.source.event
				if event:
					genreTxt = ""
					evName = event.getEventName()
					try:
						R = re.compile(r'([\(\[]).*?([\)\]])|(: odc.\d+)|(\d+: odc.\d+)|(\d+ odc.\d+)|(:)|( -(.*?).*)|(,)|!|/.*|\|\s[0-9]+\+|[0-9]+\+|\s\d{4}\Z|([\(\[\|].*?[\)\]\|])|(\"|\"\.|\"\,|\.)\s.+|\"|:|Премьера\.\s|(х|Х|м|М|т|Т|д|Д)/ф\s|(х|Х|м|М|т|Т|д|Д)/с\s|\s(с|С)(езон|ерия|-н|-я)\s.+|\s\d{1,3}\s(ч|ч\.|с\.|с)\s.+|\.\s\d{1,3}\s(ч|ч\.|с\.|с)\s.+|\s(ч|ч\.|с\.|с)\s\d{1,3}.+|\d{1,3}(-я|-й|\sс-н).+|', re.DOTALL)
						path = "%s%s.json" % (config.plugins.xtraEvent.loc.value + "xtraEvent/infos/", R.sub('', evName).strip())
						if os.path.exists(path):
							with open(path) as f:
								genreTxt = json.load(f).get("Genre", "").split(",")[0]
					except:
						pass
					if not genreTxt:
						try:
							gData = event.getGenreData()
							if gData:
								genreTxt = {1:('Thriller','Movie','Detective','Adventure','Science','Comedy','Serie','Romance','Serious','Adult'), 2:('News','Weather','Magazine','Docu','Disc'), 3:('Show','Quiz','Variety','Talk'), 4:('Sports','Special','Sports Magazine','Football','Tennis','Team Sports','Athletics','Motor Sport','Water Sport','Winter Sport','Equestrian','Martial Sports'), 5:("Childrens","Children",'entertainment (6-14)','entertainment (10-16)','Information','Cartoon'), 6:('Music','Rock/Pop','Classic Music','Folk','Jazz','Musical/Opera','Ballet'), 7:('Arts','Performing Arts','Fine Arts','Religion','PopCulture','Literature','Cinema','ExpFilm','Press','New Media','Culture','Fashion'), 8:('Social','Magazines','Economics','Remarkable People'), 9:('Education','Nature/Animals/','Technology','Medicine','Expeditions','Social','Further Education','Languages'), 10:('Hobbies','Travel','Handicraft','Motoring','Fitness','Cooking','Shopping','Gardening'), 11:('Original Language','Black & White','Unpublished','Live Broadcast')}.get(gData.getLevel1(),"")[gData.getLevel2()]
						except:
							pass
					if genreTxt:
						png = "%s%s.png" % (PIC_PATH, re.sub("[^0-9a-z]+", "_", genreTxt.lower()).replace("__", "_").strip("_"))
						if os.path.exists(png):
							self.instance.setPixmapFromFile(png)
							self.instance.setScale(1)
							self.instance.show()
							found = True
				if not found:
					self.instance.hide()
